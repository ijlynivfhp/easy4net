﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Easy4net.DBUtility
{
    public enum DbOperateType
    {
        INSERT,
        UPDATE,
        DELETE,
        SELECT,
        COUNT
    }
}
